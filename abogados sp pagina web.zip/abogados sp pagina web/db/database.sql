-- ========================================
-- BASE DE DATOS PARA CONSULTORIO JURÍDICO
-- ========================================
-- Autor: Sistema de Gestión - Abogados SP
-- Fecha: 2026-04-15
-- Descripción: Base de datos para sistema de gestión de clientes y servicios legales

-- ========================================
-- CREAR BASE DE DATOS
-- ========================================

CREATE DATABASE IF NOT EXISTS abogados_sp;
USE abogados_sp;

-- ========================================
-- TABLA DE USUARIOS (CLIENTES)
-- ========================================

CREATE TABLE IF NOT EXISTS usuarios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    telefono VARCHAR(20) NOT NULL,
    celular VARCHAR(20),
    direccion VARCHAR(255),
    barrio VARCHAR(100),
    ciudad VARCHAR(100) DEFAULT 'Presidencia Roque Sáenz Peña',
    provincia VARCHAR(100) DEFAULT 'Chaco',
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    contraseña VARCHAR(255),
    estado ENUM('activo', 'inactivo', 'suspendido') DEFAULT 'activo',
    moneda_preferida ENUM('ARS', 'USD') DEFAULT 'ARS',
    tipo_usuario ENUM('cliente', 'abogado', 'admin') DEFAULT 'cliente',
    INDEX idx_email (email),
    INDEX idx_celular (celular)
);

-- ========================================
-- TABLA DE ABOGADOS
-- ========================================

CREATE TABLE IF NOT EXISTS abogados (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT,
    numero_matricula VARCHAR(50) UNIQUE NOT NULL,
    especialidades VARCHAR(500),
    años_experiencia INT,
    biografia TEXT,
    foto_url VARCHAR(255),
    telefono_consultorio VARCHAR(20),
    whatsapp VARCHAR(20),
    email_profesional VARCHAR(120) UNIQUE,
    honorarios_minimos DECIMAL(10, 2),
    moneda ENUM('ARS', 'USD') DEFAULT 'ARS',
    estado ENUM('activo', 'inactivo') DEFAULT 'activo',
    fecha_union TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    rating_promedio DECIMAL(3, 2) DEFAULT 0,
    total_calificaciones INT DEFAULT 0,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    INDEX idx_especialidades (especialidades),
    INDEX idx_numero_matricula (numero_matricula)
);

-- ========================================
-- TABLA DE SERVICIOS OFRECIDOS
-- ========================================

CREATE TABLE IF NOT EXISTS servicios (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre_servicio VARCHAR(150) NOT NULL,
    descripcion TEXT,
    abogado_id INT,
    categoria ENUM(
        'Derecho Inmobiliario',
        'Derecho Laboral',
        'Derecho de Familia',
        'Derecho Civil',
        'Derecho Comercial',
        'Derecho Penal',
        'Otro'
    ) NOT NULL,
    precio_minimo DECIMAL(10, 2),
    precio_maximo DECIMAL(10, 2),
    moneda ENUM('ARS', 'USD') DEFAULT 'ARS',
    duracion_promedio VARCHAR(50),
    estado ENUM('activo', 'inactivo') DEFAULT 'activo',
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (abogado_id) REFERENCES abogados(id),
    INDEX idx_categoria (categoria),
    INDEX idx_abogado (abogado_id)
);

-- ========================================
-- TABLA DE CONSULTAS/CASOS
-- ========================================

CREATE TABLE IF NOT EXISTS consultas (
    id INT PRIMARY KEY AUTO_INCREMENT,
    cliente_id INT NOT NULL,
    abogado_id INT,
    servicio_id INT,
    titulo_caso VARCHAR(255) NOT NULL,
    descripcion_problema TEXT NOT NULL,
    estado ENUM('pendiente', 'en_proceso', 'resuelto', 'cerrado', 'cancelado') DEFAULT 'pendiente',
    prioridad ENUM('baja', 'media', 'alta', 'urgente') DEFAULT 'media',
    fecha_solicitud TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_asignacion DATETIME,
    fecha_resolucion DATETIME,
    presupuesto_estimado DECIMAL(10, 2),
    presupuesto_final DECIMAL(10, 2),
    moneda ENUM('ARS', 'USD') DEFAULT 'ARS',
    observaciones TEXT,
    INDEX idx_cliente (cliente_id),
    INDEX idx_abogado (abogado_id),
    INDEX idx_estado (estado),
    FOREIGN KEY (cliente_id) REFERENCES usuarios(id),
    FOREIGN KEY (abogado_id) REFERENCES abogados(id),
    FOREIGN KEY (servicio_id) REFERENCES servicios(id)
);

-- ========================================
-- TABLA DE PAGOS
-- ========================================

CREATE TABLE IF NOT EXISTS pagos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    consulta_id INT NOT NULL,
    cliente_id INT NOT NULL,
    monto DECIMAL(10, 2) NOT NULL,
    moneda ENUM('ARS', 'USD') DEFAULT 'ARS',
    metodo_pago ENUM('mercado_pago', 'transferencia', 'efectivo', 'cheque', 'tarjeta') DEFAULT 'mercado_pago',
    numero_cuota INT,
    total_cuotas INT,
    estado ENUM('pendiente', 'procesando', 'aprobado', 'rechazado', 'reembolsado') DEFAULT 'pendiente',
    fecha_pago TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_vencimiento DATE,
    numero_transaccion VARCHAR(100) UNIQUE,
    comprobante_url VARCHAR(255),
    FOREIGN KEY (consulta_id) REFERENCES consultas(id),
    FOREIGN KEY (cliente_id) REFERENCES usuarios(id),
    INDEX idx_estado (estado),
    INDEX idx_cliente (cliente_id)
);

-- ========================================
-- TABLA DE DOCUMENTOS
-- ========================================

CREATE TABLE IF NOT EXISTS documentos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    consulta_id INT NOT NULL,
    nombre_archivo VARCHAR(255) NOT NULL,
    tipo_documento ENUM('contrato', 'poder', 'demanda', 'respuesta', 'otro') DEFAULT 'otro',
    url_documento VARCHAR(255) NOT NULL,
    fecha_carga TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    cargado_por INT,
    descripcion TEXT,
    FOREIGN KEY (consulta_id) REFERENCES consultas(id),
    FOREIGN KEY (cargado_por) REFERENCES usuarios(id),
    INDEX idx_consulta (consulta_id)
);

-- ========================================
-- TABLA DE COMUNICACIONES
-- ========================================

CREATE TABLE IF NOT EXISTS comunicaciones (
    id INT PRIMARY KEY AUTO_INCREMENT,
    consulta_id INT NOT NULL,
    emisor_id INT NOT NULL,
    receptor_id INT NOT NULL,
    tipo ENUM('email', 'whatsapp', 'mensaje_interno', 'llamada') DEFAULT 'mensaje_interno',
    asunto VARCHAR(255),
    mensaje TEXT NOT NULL,
    fecha_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_lectura DATETIME,
    archivo_adjunto VARCHAR(255),
    FOREIGN KEY (consulta_id) REFERENCES consultas(id),
    FOREIGN KEY (emisor_id) REFERENCES usuarios(id),
    FOREIGN KEY (receptor_id) REFERENCES usuarios(id),
    INDEX idx_consulta (consulta_id),
    INDEX idx_no_leido (fecha_lectura)
);

-- ========================================
-- TABLA DE CALIFICACIONES Y RESEÑAS
-- ========================================

CREATE TABLE IF NOT EXISTS calificaciones (
    id INT PRIMARY KEY AUTO_INCREMENT,
    consulta_id INT NOT NULL,
    cliente_id INT NOT NULL,
    abogado_id INT NOT NULL,
    puntuacion INT CHECK (puntuacion >= 1 AND puntuacion <= 5),
    comentario TEXT,
    fecha_calificacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    estado ENUM('pendiente', 'aprobada', 'rechazada') DEFAULT 'pendiente',
    FOREIGN KEY (consulta_id) REFERENCES consultas(id),
    FOREIGN KEY (cliente_id) REFERENCES usuarios(id),
    FOREIGN KEY (abogado_id) REFERENCES abogados(id),
    INDEX idx_abogado (abogado_id),
    UNIQUE KEY unique_calificacion (consulta_id)
);

-- ========================================
-- TABLA DE HORARIOS DE DISPONIBILIDAD
-- ========================================

CREATE TABLE IF NOT EXISTS horarios_disponibles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    abogado_id INT NOT NULL,
    dia_semana ENUM('lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo'),
    hora_inicio TIME,
    hora_fin TIME,
    cantidad_citas INT DEFAULT 5,
    citas_disponibles INT DEFAULT 5,
    estado ENUM('activo', 'inactivo') DEFAULT 'activo',
    FOREIGN KEY (abogado_id) REFERENCES abogados(id),
    INDEX idx_abogado (abogado_id)
);

-- ========================================
-- TABLA DE CITAS/AUDIENCIAS
-- ========================================

CREATE TABLE IF NOT EXISTS citas (
    id INT PRIMARY KEY AUTO_INCREMENT,
    consulta_id INT NOT NULL,
    cliente_id INT NOT NULL,
    abogado_id INT NOT NULL,
    fecha_hora DATETIME NOT NULL,
    tipo_cita ENUM('consulta', 'seguimiento', 'firma', 'audiencia') DEFAULT 'consulta',
    lugar VARCHAR(255),
    duracion_minutos INT DEFAULT 60,
    estado ENUM('programada', 'completada', 'cancelada', 'reprogramada') DEFAULT 'programada',
    notas_abogado TEXT,
    notas_cliente TEXT,
    recordatorio_enviado BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (consulta_id) REFERENCES consultas(id),
    FOREIGN KEY (cliente_id) REFERENCES usuarios(id),
    FOREIGN KEY (abogado_id) REFERENCES abogados(id),
    INDEX idx_fecha (fecha_hora),
    INDEX idx_abogado (abogado_id)
);

-- ========================================
-- TABLA DE GASTOS Y COSTOS
-- ========================================

CREATE TABLE IF NOT EXISTS costos_casos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    consulta_id INT NOT NULL,
    descripcion VARCHAR(255) NOT NULL,
    tipo_costo ENUM('arancelario', 'pericial', 'transporte', 'documentación', 'otro') DEFAULT 'otro',
    monto DECIMAL(10, 2) NOT NULL,
    moneda ENUM('ARS', 'USD') DEFAULT 'ARS',
    fecha_gasto DATE DEFAULT CURDATE(),
    responsable_pago INT,
    estado ENUM('pendiente', 'pagado', 'reembolsable') DEFAULT 'pendiente',
    FOREIGN KEY (consulta_id) REFERENCES consultas(id),
    FOREIGN KEY (responsable_pago) REFERENCES usuarios(id),
    INDEX idx_consulta (consulta_id)
);

-- ========================================
-- TABLA DE AUDITORÍA
-- ========================================

CREATE TABLE IF NOT EXISTS auditoria (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario_id INT,
    accion VARCHAR(255) NOT NULL,
    tabla_afectada VARCHAR(100),
    registro_id INT,
    cambios_previos TEXT,
    cambios_nuevos TEXT,
    fecha_accion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address VARCHAR(45),
    estado ENUM('exitoso', 'error') DEFAULT 'exitoso',
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    INDEX idx_fecha (fecha_accion),
    INDEX idx_usuario (usuario_id)
);

-- ========================================
-- CREAR ÍNDICES ADICIONALES
-- ========================================

CREATE INDEX idx_usuarios_ciudad ON usuarios(ciudad, provincia);
CREATE INDEX idx_consultas_fecha ON consultas(fecha_solicitud);
CREATE INDEX idx_pagos_fecha ON pagos(fecha_pago);
CREATE INDEX idx_consultas_estado_abogado ON consultas(estado, abogado_id);

-- ========================================
-- DATOS DE EJEMPLO
-- ========================================

-- Insertar usuarios (clientes)
INSERT INTO usuarios (nombre, apellido, email, telefono, celular, barrio, moneda_preferida, tipo_usuario)
VALUES 
    ('Juan', 'García', 'juan.garcia@email.com', '03644-123456', '03644-123456', 'Centro', 'ARS', 'cliente'),
    ('María', 'López', 'maria.lopez@email.com', '03644-234567', '03644-234567', 'San Martín', 'ARS', 'cliente'),
    ('Carlos', 'Rodríguez', 'carlos.rodriguez@email.com', '03644-345678', '03644-369163', 'Centro', 'ARS', 'abogado'),
    ('Ana', 'Martínez', 'ana.martinez@email.com', '03644-456789', '03644-456789', 'Lourdes', 'ARS', 'abogado'),
    ('Roberto', 'Sánchez', 'roberto.sanchez@email.com', '03644-567890', '03644-567890', 'Centro', 'USD', 'cliente'),
    ('Claudia', 'Fernández', 'claudia.fernandez@email.com', '03644-678901', '03644-678901', 'San Martín', 'ARS', 'abogado'),
    ('Andrés', 'Gómez', 'andres.gomez@email.com', '03644-789012', '03644-789012', 'Centro', 'ARS', 'abogado'),
    ('Valentina', 'Torres', 'valentina.torres@email.com', '03644-890123', '03644-890123', 'Lourdes', 'ARS', 'abogado');

-- Insertar abogados
INSERT INTO abogados (usuario_id, numero_matricula, especialidades, años_experiencia, email_profesional, whatsapp)
VALUES 
    (3, 'MAT-CHACO-2024-001', 'Derecho Civil, Derecho Inmobiliario', 15, 'carlos.rodriguez@abogadosp.com', '+5493644369163'),
    (4, 'MAT-CHACO-2024-002', 'Derecho Laboral, Derecho Comercial', 10, 'ana.martinez@abogadosp.com', '+5493644369163'),
    (6, 'MAT-CHACO-2024-003', 'Derecho de Familia, Derecho Civil', 8, 'claudia.fernandez@abogadosp.com', '+5493644369163'),
    (7, 'MAT-CHACO-2024-004', 'Derecho Comercial, Derecho Civil', 9, 'andres.gomez@abogadosp.com', '+5493644369163'),
    (8, 'MAT-CHACO-2024-005', 'Derecho Inmobiliario, Derecho Civil', 7, 'valentina.torres@abogadosp.com', '+5493644369163');

-- Insertar servicios
INSERT INTO servicios (nombre_servicio, descripcion, abogado_id, categoria, precio_minimo, precio_maximo, moneda)
VALUES 
    ('Asesoramiento en Compraventa de Inmuebles', 'Orientación completa en transacciones inmobiliarias', 1, 'Derecho Inmobiliario', 5000.00, 15000.00, 'ARS'),
    ('Defensa en Conflictos Laborales', 'Representación legal en disputas con empleadores', 2, 'Derecho Laboral', 8000.00, 25000.00, 'ARS'),
    ('Constitución de Empresas', 'Trámites para crear empresas y estructuras comerciales', 2, 'Derecho Comercial', 10000.00, 30000.00, 'ARS'),
    ('Tramitación de Herencias', 'Orientación en procesos sucesorios', 1, 'Derecho Civil', 7000.00, 20000.00, 'ARS'),
    ('Asesoramiento en Divorcios', 'Representación integral en procesos de separación', 3, 'Derecho de Familia', 6000.00, 18000.00, 'ARS'),
    ('Custodia y Pensión Alimenticia', 'Defensa de derechos en asuntos de menores', 3, 'Derecho de Familia', 5500.00, 16000.00, 'ARS'),
    ('Registro de Marcas y Patentes', 'Protección de propiedad intelectual empresarial', 4, 'Derecho Comercial', 9000.00, 25000.00, 'ARS'),
    ('Contratos Comerciales', 'Redacción y revisión de contratos de negocios', 4, 'Derecho Comercial', 7500.00, 20000.00, 'ARS'),
    ('Gestión de Propiedades', 'Administración y trámites de inmuebles', 5, 'Derecho Inmobiliario', 6000.00, 17000.00, 'ARS'),
    ('Litigios Inmobiliarios', 'Representación en conflictos de propiedad', 5, 'Derecho Inmobiliario', 8000.00, 22000.00, 'ARS');

-- ========================================
-- VISTAS ÚTILES
-- ========================================

-- Vista de consultas activas por abogado
CREATE VIEW IF NOT EXISTS consultas_activas_abogado AS
SELECT 
    a.id as abogado_id,
    CONCAT(a.nombre_matricula, ' - ', u.nombre, ' ', u.apellido) as abogado,
    COUNT(c.id) as total_consultas_activas,
    SUM(CASE WHEN c.estado = 'en_proceso' THEN 1 ELSE 0 END) as en_proceso,
    SUM(CASE WHEN c.estado = 'pendiente' THEN 1 ELSE 0 END) as pendientes
FROM abogados a
LEFT JOIN usuarios u ON a.usuario_id = u.id
LEFT JOIN consultas c ON a.id = c.abogado_id AND c.estado IN ('pendiente', 'en_proceso')
GROUP BY a.id, a.numero_matricula, u.nombre, u.apellido;

-- Vista de ingresos mensuales
CREATE VIEW IF NOT EXISTS ingresos_mensuales AS
SELECT 
    DATE_TRUNC(p.fecha_pago, MONTH) as mes,
    SUM(p.monto) as ingreso_total,
    p.moneda,
    COUNT(DISTINCT p.cliente_id) as total_clientes
FROM pagos p
WHERE p.estado = 'aprobado'
GROUP BY mes, p.moneda;

-- ========================================
-- PROCEDIMIENTOS ALMACENADOS
-- ========================================

DELIMITER //

-- Procedimiento para registrar nueva consulta
CREATE PROCEDURE registrar_consulta(
    IN p_cliente_id INT,
    IN p_titulo VARCHAR(255),
    IN p_descripcion TEXT,
    IN p_categoria VARCHAR(100),
    IN p_moneda ENUM('ARS', 'USD')
)
BEGIN
    INSERT INTO consultas (cliente_id, titulo_caso, descripcion_problema, estado, moneda)
    VALUES (p_cliente_id, p_titulo, p_descripcion, 'pendiente', p_moneda);
    
    INSERT INTO auditoria (usuario_id, accion, tabla_afectada, registro_id)
    VALUES (p_cliente_id, 'Nueva consulta creada', 'consultas', LAST_INSERT_ID());
END//

-- Procedimiento para actualizar rating de abogado
CREATE PROCEDURE actualizar_rating_abogado(
    IN p_abogado_id INT
)
BEGIN
    UPDATE abogados a
    SET 
        rating_promedio = (
            SELECT AVG(c.puntuacion) 
            FROM calificaciones c 
            WHERE c.abogado_id = p_abogado_id AND c.estado = 'aprobada'
        ),
        total_calificaciones = (
            SELECT COUNT(*) 
            FROM calificaciones c 
            WHERE c.abogado_id = p_abogado_id AND c.estado = 'aprobada'
        )
    WHERE a.id = p_abogado_id;
END//

DELIMITER ;

-- ========================================
-- PERMISOS Y SEGURIDAD
-- ========================================

-- Crear usuario específico para la aplicación web
-- CREATE USER 'abogados_app'@'localhost' IDENTIFIED BY 'ContrasenaSegura123';
-- GRANT SELECT, INSERT, UPDATE ON abogados_sp.* TO 'abogados_app'@'localhost';
-- FLUSH PRIVILEGES;

-- ========================================
-- NOTAS FINALES
-- ========================================
/*
Esta base de datos está diseñada para manejar:

1. Gestión de Clientes y Usuarios: Registro, actualización y administración de información personal
2. Gestión de Abogados: Perfiles profesionales, especialidades y disponibilidad
3. Administración de Casos: Seguimiento completo desde consulta inicial hasta resolución
4. Control de Pagos: Seguimiento de facturas, cuotas de Mercado Pago y otros métodos
5. Documentación: Almacenamiento de referencias a documentos legales
6. Comunicación: Registro de todas las comunicaciones cliente-abogado
7. Calificaciones: Sistema de reseñas y ratings para abogados
8. Auditoría: Seguimiento de todas las acciones del sistema

IMPORTANTE:
- Ajusta las contraseñas de usuario antes de usar en producción
- Configura los backups automáticos
- Usa SSL para todas las conexiones a la base de datos
- Implementa validación de entrada en la aplicación web
- Cumple con regulaciones de protección de datos personales
*/
