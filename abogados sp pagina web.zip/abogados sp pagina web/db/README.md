# Base de Datos - Abogados SP

## Descripción General

Esta carpeta contiene el archivo de base de datos SQL para la plataforma de servicios legales "Abogados SP" en Presidencia Roque Sáenz Peña, Chaco.

## Archivo Principal: `database.sql`

### Tablas Principales

#### 1. **usuarios**
Almacena información de todos los usuarios del sistema (clientes, abogados, administradores).

- Campos: nombre, apellido, email, teléfono, dirección, barrio, ciudad, provincia, etc.
- Tipos de usuario: cliente, abogado, admin
- Estado: activo, inactivo, suspendido

#### 2. **abogados**
Perfil profesional de los abogados registrados.

- Número de matrícula
- Especialidades (Derecho Civil, Laboral, Penal, etc.)
- Años de experiencia
- Foto y datos de contacto profesional
- Rating promedio y total de calificaciones

#### 3. **servicios**
Catálogo de servicios ofrecidos por cada abogado.

- Nombre y descripción del servicio
- Categoría (Derecho Inmobiliario, Laboral, Familia, etc.)
- Precios en ARS y USD
- Duración promedio estimada

#### 4. **consultas**
Registro de casos/consultas solicitadas por clientes.

- Estado: pendiente, en proceso, resuelto, cerrado, cancelado
- Prioridad del caso
- Presupuesto estimado y final
- Fechas de solicitud, asignación y resolución

#### 5. **pagos**
Control de pagos y facturas.

- Métodos: Mercado Pago, transferencia, efectivo, cheque, tarjeta
- Sistema de cuotas (número de cuota / total cuotas)
- Estado: pendiente, procesando, aprobado, rechazado, reembolsado
- Moneda: ARS o USD

#### 6. **documentos**
Almacenamiento de referencias a documentos legales.

- Tipos: contrato, poder, demanda, respuesta, otro
- URL/ruta del documento
- Fecha de carga y usuario que cargó

#### 7. **comunicaciones**
Registro de todas las comunicaciones.

- Tipo: email, WhatsApp, mensaje interno, llamada
- Emisor y receptor
- Fecha de envío y lectura
- Archivos adjuntos

#### 8. **calificaciones**
Sistema de reseñas y ratings para abogados.

- Puntuación de 1 a 5
- Comentario del cliente
- Estado: pendiente, aprobada, rechazada

#### 9. **horarios_disponibles**
Disponibilidad de cada abogado.

- Día de la semana
- Hora de inicio y fin
- Cantidad de citas disponibles

#### 10. **citas**
Registro de citas y audiencias.

- Tipo: consulta, seguimiento, firma, audiencia
- Lugar y duración
- Estado: programada, completada, cancelada, reprogramada
- Notas del abogado y cliente
- Control de recordatorios

#### 11. **costos_casos**
Tracking de gastos adicionales en casos.

- Tipo de costo: arancelario, pericial, transporte, documentación
- Responsable del pago
- Estado: pendiente, pagado, reembolsable

#### 12. **auditoria**
Registro de auditoría de todas las acciones del sistema.

- Acción realizada
- Tabla y registro afectados
- Cambios previos y nuevos
- IP del usuario

## Instalación

### Requisitos
- Servidor MySQL 8.0 o superior (o MariaDB equivalente)
- Acceso como administrador a la base de datos

### Pasos

1. **Conectarse a MySQL:**
```bash
mysql -u root -p
```

2. **Importar el archivo SQL:**
```bash
mysql -u root -p < database.sql
```

O dentro de MySQL:
```sql
SOURCE /ruta/al/database.sql;
```

3. **Verificar la instalación:**
```sql
USE abogados_sp;
SHOW TABLES;
```

## Configuración de Usuario para la Aplicación Web

Para mayor seguridad, crea un usuario específico para la aplicación:

```sql
CREATE USER 'abogados_app'@'localhost' IDENTIFIED BY 'TuContraseñaSegura123';
GRANT SELECT, INSERT, UPDATE ON abogados_sp.* TO 'abogados_app'@'localhost';
FLUSH PRIVILEGES;
```

## Conexión desde la Aplicación Web

### Configuración en PHP (ejemplo)

```php
<?php
$servidor = 'localhost';
$usuario = 'abogados_app';
$contrasena = 'TuContraseñaSegura123';
$basedatos = 'abogados_sp';

$conexion = new mysqli($servidor, $usuario, $contrasena, $basedatos);

if ($conexion->connect_error) {
    die('Error de conexión: ' . $conexion->connect_error);
}

// La conexión está lista para usar
?>
```

### Configuración en Node.js (ejemplo)

```javascript
const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'abogados_app',
    password: 'TuContraseñaSegura123',
    database: 'abogados_sp'
});

connection.connect((err) => {
    if (err) throw err;
    console.log('Conectado a la base de datos');
});
```

## Vistas Disponibles

### 1. **consultas_activas_abogado**
Muestra consultas activas por abogado con conteo de estado.

### 2. **ingresos_mensuales**
Resumen de ingresos mensuales por moneda.

## Procedimientos Almacenados

### 1. **registrar_consulta()**
Registra una nueva consulta y genera entrada en auditoría.

```sql
CALL registrar_consulta(1, 'Título de caso', 'Descripción del problema', 'Derecho Civil', 'ARS');
```

### 2. **actualizar_rating_abogado()**
Actualiza el rating promedio de un abogado basado en calificaciones aprobadas.

```sql
CALL actualizar_rating_abogado(1);
```

## Copia de Seguridad

### Crear backup
```bash
mysqldump -u root -p abogados_sp > backup_abogados_sp_$(date +%Y%m%d).sql
```

### Restaurar desde backup
```bash
mysql -u root -p abogados_sp < backup_abogados_sp_20260415.sql
```

## Consultas Útiles

### Obtener consultas por estado
```sql
SELECT estado, COUNT(*) as total 
FROM consultas 
GROUP BY estado;
```

### Abogados con mejor rating
```sql
SELECT * FROM abogados 
ORDER BY rating_promedio DESC 
LIMIT 5;
```

### Ingresos totales en el mes
```sql
SELECT SUM(monto) as ingreso_total, moneda 
FROM pagos 
WHERE MONTH(fecha_pago) = MONTH(CURDATE()) 
AND YEAR(fecha_pago) = YEAR(CURDATE())
AND estado = 'aprobado'
GROUP BY moneda;
```

### Clientes más activos
```sql
SELECT u.id, CONCAT(u.nombre, ' ', u.apellido) as cliente, COUNT(c.id) as total_consultas
FROM usuarios u
LEFT JOIN consultas c ON u.id = c.cliente_id
WHERE u.tipo_usuario = 'cliente'
GROUP BY u.id, u.nombre, u.apellido
ORDER BY total_consultas DESC;
```

## Seguridad

### Recomendaciones

1. **Contraseñas Fuertes:**
   - Usa contraseñas de al menos 12 caracteres
   - Incluye mayúsculas, minúsculas, números y símbolos

2. **Acceso:**
   - Limita el acceso a la base de datos solo desde localhost o IPs específicas
   - Nunca expongas credenciales en el código

3. **Backups:**
   - Realiza backups diarios
   - Almacena copias en ubicación segura externa

4. **Logs:**
   - Monitorea la tabla de auditoría regularmente
   - Revisa intentos de acceso fallidos

5. **SSL:**
   - Usa conexiones SSL para conexiones remotas
   - Cifra datos sensibles

## Mantenimiento

### Optimización Regular

```sql
-- Optimizar todas las tablas
OPTIMIZE TABLE usuarios;
OPTIMIZE TABLE abogados;
OPTIMIZE TABLE consultas;
OPTIMIZE TABLE pagos;
-- ... etc para todas las tablas
```

### Verificación de Integridad

```sql
CHECK TABLE usuarios;
CHECK TABLE abogados;
CHECK TABLE consultas;
-- ... etc para todas las tablas
```

## Soporte y Contacto

Para consultas o problemas con la base de datos:
- Teléfono: +54 3644-369163
- WhatsApp: +54 3644-369163
- Email: contacto@abogadosp.com

---

**Última actualización:** 15 de abril de 2026
