<?php
/**
 * CONFIGURACIÓN DE CONEXIÓN A BASE DE DATOS
 * Archivo de configuración para la aplicación Abogados SP
 * 
 * IMPORTANTE: Protege este archivo en producción
 * No lo expongas en repositorios públicos
 */

// ========================================
// CONFIGURACIÓN DE BASE DE DATOS
// ========================================

// Servidor de base de datos
define('DB_HOST', 'localhost');

// Usuario de base de datos
define('DB_USER', 'abogados_app');

// Contraseña de base de datos
// ⚠️ CAMBIA ESTO POR UNA CONTRASEÑA SEGURA EN PRODUCCIÓN
define('DB_PASS', 'TuContraseñaSegura123');

// Nombre de la base de datos
define('DB_NAME', 'abogados_sp');

// Puerto de MySQL (por defecto 3306)
define('DB_PORT', 3306);

// ========================================
// OPCIONES DE CONEXIÓN
// ========================================

// Charset para la conexión
define('DB_CHARSET', 'utf8mb4');

// Zona horaria
define('DB_TIMEZONE', 'America/Argentina/Buenos_Aires');

// ========================================
// CONFIGURACIÓN DE APLICACIÓN
// ========================================

// URL base de la aplicación
define('BASE_URL', 'https://abogadosp.com/');

// Moneda predeterminada
define('DEFAULT_CURRENCY', 'ARS');

// ========================================
// CONFIGURACIÓN DE FORMSPREE
// ========================================

// ID del formulario de Formspree para contacto
// Obtén tu ID en: https://formspree.io/
define('FORMSPREE_ID', 'YOUR_FORM_ID');

// ========================================
// CONFIGURACIÓN DE WHATSAPP
// ========================================

// Número de WhatsApp de la empresa
define('WHATSAPP_NUMBER', '5493644369163');

// URL de API de WhatsApp (si usas un servicio)
define('WHATSAPP_API_URL', 'https://api.whatsapp.com/send');

// ========================================
// CONFIGURACIÓN DE CORREO
// ========================================

// Email principal de la empresa
define('EMAIL_CONTACTO', 'contacto@abogadosp.com');

// Email para notificaciones internas
define('EMAIL_NOTIFICACIONES', 'notificaciones@abogadosp.com');

// Servidor SMTP
define('SMTP_HOST', 'smtp.gmail.com');

// Puerto SMTP
define('SMTP_PORT', 587);

// Usuario SMTP
define('SMTP_USER', 'tu_email@gmail.com');

// Contraseña SMTP (usa contraseña de aplicación para Gmail)
define('SMTP_PASS', 'tu_contraseña_app');

// ========================================
// CONFIGURACIÓN DE MERCADO PAGO
// ========================================

// Token de acceso de Mercado Pago
// Obtén en: https://www.mercadopago.com.ar/developers/panel
define('MERCADO_PAGO_TOKEN', 'YOUR_ACCESS_TOKEN');

// ID de usuario de Mercado Pago
define('MERCADO_PAGO_USER_ID', 'YOUR_USER_ID');

// ========================================
// CONFIGURACIÓN DE SEGURIDAD
// ========================================

// Clave secreta para tokens JWT
define('JWT_SECRET', 'tu_clave_secreta_muy_segura_aqui');

// Tiempo de expiración de sesión (en segundos)
define('SESSION_TIMEOUT', 3600); // 1 hora

// Máximo de intentos de login fallidos
define('MAX_LOGIN_ATTEMPTS', 5);

// Tiempo de bloqueo después de intentos fallidos (en segundos)
define('LOCKOUT_TIME', 900); // 15 minutos

// ========================================
// CONFIGURACIÓN DE MODO DEBUG
// ========================================

// Modo desarrollo (true) o producción (false)
define('DEBUG_MODE', false);

// Mostrar errores de PHP
define('DISPLAY_ERRORS', DEBUG_MODE);

// Registrar errores en archivo
define('LOG_ERRORS', true);

// Archivo de log de errores
define('ERROR_LOG_FILE', __DIR__ . '/logs/error.log');

// Archivo de log de acceso
define('ACCESS_LOG_FILE', __DIR__ . '/logs/access.log');

// ========================================
// FUNCIÓN DE CONEXIÓN
// ========================================

/**
 * Establece conexión a la base de datos
 * 
 * @return mysqli|false Objeto de conexión o false si falla
 */
function conectar_bd() {
    try {
        // Crear conexión
        $conexion = new mysqli(
            DB_HOST,
            DB_USER,
            DB_PASS,
            DB_NAME,
            DB_PORT
        );

        // Verificar conexión
        if ($conexion->connect_error) {
            throw new Exception('Error de conexión: ' . $conexion->connect_error);
        }

        // Establecer charset
        if (!$conexion->set_charset(DB_CHARSET)) {
            throw new Exception('Error al establecer charset: ' . $conexion->error);
        }

        // Establecer zona horaria
        $conexion->query("SET time_zone = '" . DB_TIMEZONE . "'");

        return $conexion;

    } catch (Exception $e) {
        if (DEBUG_MODE) {
            echo 'Error: ' . $e->getMessage();
        }
        registrar_error('Error de conexión BD: ' . $e->getMessage());
        return false;
    }
}

// ========================================
// FUNCIONES AUXILIARES
// ========================================

/**
 * Registra errores en archivo de log
 * 
 * @param string $mensaje Mensajeaerror
 * @param string $tipo Tipo de error (ERROR, WARNING, INFO)
 */
function registrar_error($mensaje, $tipo = 'ERROR') {
    if (!LOG_ERRORS) {
        return;
    }

    $fecha = date('Y-m-d H:i:s');
    $log_message = "[$fecha] [$tipo] $mensaje\n";

    error_log($log_message, 3, ERROR_LOG_FILE);
}

/**
 * Registra acceso a la aplicación
 * 
 * @param string $usuario Usuario que accedió
 * @param string $accion Acción realizada
 */
function registrar_acceso($usuario, $accion) {
    if (!LOG_ERRORS) {
        return;
    }

    $fecha = date('Y-m-d H:i:s');
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $log_message = "[$fecha] Usuario: $usuario | Acción: $accion | IP: $ip\n";

    error_log($log_message, 3, ACCESS_LOG_FILE);
}

// ========================================
// SANITIZACIÓN Y VALIDACIÓN
// ========================================

/**
 * Limpia y escapa entrada de usuario
 * 
 * @param string $data Datos a limpiar
 * @param mysqli $conexion Conexión BD
 * @return string Datos limpiados
 */
function limpiar_entrada($data, $conexion) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $conexion->real_escape_string($data);
}

/**
 * Valida email
 * 
 * @param string $email Email a validar
 * @return bool true si es válido
 */
function validar_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Valida teléfono
 * 
 * @param string $telefono Teléfono a validar
 * @return bool true si es válido
 */
function validar_telefono($telefono) {
    // Patrón para teléfono argentino
    $patron = '/^(\+?54)?[\s]?(11|2[0-9]{1}|3[0-9]{1})[\s]?([0-9]{4})[\s]?([0-9]{4})$/';
    return preg_match($patron, preg_replace('/\D/', '', $telefono)) === 1;
}

// ========================================
// CREAR DIRECTORIOS DE LOG SI NO EXISTEN
// ========================================

$log_dir = __DIR__ . '/logs';
if (!is_dir($log_dir)) {
    mkdir($log_dir, 0755, true);
}

// ========================================
// CONFIGURAR MANEJO DE ERRORES
// ========================================

if (DEBUG_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', DISPLAY_ERRORS);
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', '0');
}

ini_set('log_errors', LOG_ERRORS);
ini_set('error_log', ERROR_LOG_FILE);

// ========================================
// CONFIGURAR SESIÓN
// ========================================

session_set_cookie_params([
    'lifetime' => SESSION_TIMEOUT,
    'path' => '/',
    'domain' => $_SERVER['HTTP_HOST'] ?? 'localhost',
    'secure' => !DEBUG_MODE, // Usar HTTPS en producción
    'httponly' => true,
    'samesite' => 'Strict'
]);

// ========================================
// FIN DEL ARCHIVO
// ========================================
?>
