// ========================================
// FUNCIONES GENERALES
// ========================================

// Desplazamiento suave hacia el formulario de contacto
function scrollToContacto() {
    const contactSection = document.getElementById('contacto');
    contactSection.scrollIntoView({ behavior: 'smooth' });
}

// ========================================
// VALIDACIÓN DE FORMULARIO
// ========================================

const contactForm = document.getElementById('contactForm');
const formFields = {
    nombre: document.getElementById('nombre'),
    apellido: document.getElementById('apellido'),
    celular: document.getElementById('celular'),
    email: document.getElementById('email'),
    servicio: document.getElementById('servicio'),
    mensaje: document.getElementById('mensaje'),
    terminos: document.getElementById('terminos')
};

// Validadores
const validators = {
    nombre: (value) => {
        if (!value.trim()) return 'El nombre es requerido';
        if (value.trim().length < 2) return 'El nombre debe tener al menos 2 caracteres';
        if (!/^[a-záéíóúñ\s]+$/i.test(value)) return 'El nombre solo debe contener letras';
        return null;
    },
    apellido: (value) => {
        if (!value.trim()) return 'El apellido es requerido';
        if (value.trim().length < 2) return 'El apellido debe tener al menos 2 caracteres';
        if (!/^[a-záéíóúñ\s]+$/i.test(value)) return 'El apellido solo debe contener letras';
        return null;
    },
    celular: (value) => {
        if (!value.trim()) return 'El teléfono es requerido';
        if (!/^[\d\s\-\+]+$/.test(value)) return 'El teléfono solo debe contener números y símbolos válidos';
        if (value.replace(/\D/g, '').length < 10) return 'El teléfono debe tener al menos 10 dígitos';
        return null;
    },
    email: (value) => {
        if (!value.trim()) return 'El correo es requerido';
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) return 'Ingresa un correo válido ej: usuario@ejemplo.com';
        return null;
    },
    servicio: (value) => {
        if (!value) return 'Debes seleccionar un servicio';
        return null;
    },
    mensaje: (value) => {
        if (!value.trim()) return 'Por favor describe tu caso brevemente';
        if (value.trim().length < 10) return 'El mensaje debe tener al menos 10 caracteres';
        return null;
    },
    terminos: (checked) => {
        if (!checked) return 'Debes aceptar los términos y condiciones';
        return null;
    }
};

// Función para mostrar/ocultar errores
function showError(fieldName, message) {
    const errorElement = document.getElementById('error' + fieldName.charAt(0).toUpperCase() + fieldName.slice(1));
    if (message) {
        errorElement.textContent = message;
        errorElement.classList.add('show');
        if (formFields[fieldName]) {
            formFields[fieldName].style.borderColor = 'var(--color-danger)';
            formFields[fieldName].style.backgroundColor = '#fff5f5';
        }
    } else {
        errorElement.textContent = '';
        errorElement.classList.remove('show');
        if (formFields[fieldName]) {
            formFields[fieldName].style.borderColor = 'var(--color-border)';
            formFields[fieldName].style.backgroundColor = 'var(--color-white)';
        }
    }
}

// Validación en tiempo real
Object.keys(formFields).forEach(fieldName => {
    if (fieldName === 'terminos') {
        formFields[fieldName].addEventListener('change', () => {
            const error = validators[fieldName](formFields[fieldName].checked);
            showError(fieldName, error);
        });
    } else if (fieldName !== 'terminos') {
        formFields[fieldName].addEventListener('blur', () => {
            const error = validators[fieldName](formFields[fieldName].value);
            showError(fieldName, error);
        });

        // Limpiar error mientras escribes
        formFields[fieldName].addEventListener('input', () => {
            if (document.getElementById('error' + fieldName.charAt(0).toUpperCase() + fieldName.slice(1)).classList.contains('show')) {
                const error = validators[fieldName](formFields[fieldName].value);
                showError(fieldName, error);
            }
        });
    }
});

// Validación al enviar formulario
contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    // Validar todos los campos
    let formIsValid = true;
    Object.keys(validators).forEach(fieldName => {
        let value;
        if (fieldName === 'terminos') {
            value = formFields[fieldName].checked;
        } else {
            value = formFields[fieldName].value;
        }

        const error = validators[fieldName](value);
        if (error) {
            showError(fieldName, error);
            formIsValid = false;
        } else {
            showError(fieldName, null);
        }
    });

    if (formIsValid) {
        // Preparar datos para Formspree
        const formData = new FormData(contactForm);
        
        // Aquí va tu Form ID de Formspree
        // Reemplaza YOUR_FORM_ID con tu ID
        const formspreeID = 'YOUR_FORM_ID';

        try {
            // Enviar a Formspree
            const response = await fetch(`https://formspree.io/f/${formspreeID}`, {
                method: 'POST',
                body: formData,
                headers: {
                    'Accept': 'application/json'
                }
            });

            if (response.ok) {
                // Mostrar mensaje de éxito
                showSuccessMessage();
                contactForm.reset();
                
                // Limpiar errores visuales
                Object.keys(formFields).forEach(fieldName => {
                    showError(fieldName, null);
                });
            } else {
                showErrorMessage('Hubo un error al enviar el formulario. Intenta de nuevo.');
            }
        } catch (error) {
            console.error('Error:', error);
            showErrorMessage('No se pudo conectar con el servidor. Intenta de nuevo más tarde.');
        }
    } else {
        showErrorMessage('Por favor corrige los errores en el formulario antes de enviar.');
    }
});

// Función para mostrar mensaje de éxito
function showSuccessMessage() {
    const message = document.createElement('div');
    message.className = 'success-message';
    message.innerHTML = `
        <div class="success-content">
            <i class="fas fa-check-circle"></i>
            <h3>¡Solicitud enviada exitosamente!</h3>
            <p>Nos pondremos en contacto pronto a través de WhatsApp o correo electrónico.</p>
        </div>
    `;
    document.body.appendChild(message);

    setTimeout(() => {
        message.remove();
    }, 5000);
}

// Función para mostrar mensaje de error
function showErrorMessage(text) {
    const message = document.createElement('div');
    message.className = 'error-notification';
    message.innerHTML = `
        <div class="error-content">
            <i class="fas fa-exclamation-circle"></i>
            <p>${text}</p>
        </div>
    `;
    document.body.appendChild(message);

    setTimeout(() => {
        message.remove();
    }, 5000);
}

// Agregar estilos para mensajes de éxito y error
const style = document.createElement('style');
style.textContent = `
    .success-message, .error-notification {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 1000;
        animation: slideInRight 0.3s ease;
    }

    .success-content {
        background-color: var(--color-success);
        color: white;
        padding: 20px;
        border-radius: 8px;
        box-shadow: var(--shadow-lg);
        display: flex;
        align-items: center;
        gap: 15px;
    }

    .success-content i {
        font-size: 1.5rem;
    }

    .success-content h3 {
        margin: 0 0 5px 0;
        color: white;
    }

    .success-content p {
        margin: 0;
        color: rgba(255, 255, 255, 0.9);
    }

    .error-content {
        background-color: var(--color-danger);
        color: white;
        padding: 20px;
        border-radius: 8px;
        box-shadow: var(--shadow-lg);
        display: flex;
        align-items: center;
        gap: 15px;
    }

    .error-content i {
        font-size: 1.5rem;
    }

    .error-content p {
        margin: 0;
        color: rgba(255, 255, 255, 0.9);
    }

    @keyframes slideInRight {
        from {
            opacity: 0;
            transform: translateX(100px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }

    @media (max-width: 768px) {
        .success-message, .error-notification {
            right: 10px;
            left: 10px;
            top: auto;
            bottom: 20px;
        }

        .success-content, .error-content {
            flex-direction: column;
            text-align: center;
        }
    }
`;
document.head.appendChild(style);

// ========================================
// FUNCIONALIDAD ADICIONAL
// ========================================

// Efecto de scroll suave para navegación
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        if (href !== '#' && document.querySelector(href)) {
            e.preventDefault();
            document.querySelector(href).scrollIntoView({
                behavior: 'smooth'
            });
        }
    });
});

// Contador de caracteres para el textarea
const messageTextarea = document.getElementById('mensaje');
if (messageTextarea) {
    messageTextarea.addEventListener('input', () => {
        const remaining = 500 - messageTextarea.value.length;
        if (remaining < 0) {
            messageTextarea.value = messageTextarea.value.substring(0, 500);
        }
    });
}

// Cargar datos del formulario en localStorage para recuperación ante errores
const formInputs = document.querySelectorAll('#contactForm input, #contactForm select, #contactForm textarea');
formInputs.forEach(input => {
    // Recuperar datos guardados
    const savedValue = localStorage.getItem(`contactForm_${input.id}`);
    if (savedValue && input.type !== 'checkbox') {
        input.value = savedValue;
    } else if (savedValue && input.type === 'checkbox') {
        input.checked = savedValue === 'true';
    }

    // Guardar datos mientras escriben
    input.addEventListener('change', () => {
        if (input.type === 'checkbox') {
            localStorage.setItem(`contactForm_${input.id}`, input.checked);
        } else {
            localStorage.setItem(`contactForm_${input.id}`, input.value);
        }
    });
});

// Limpiar localStorage cuando se envía exitosamente
contactForm.addEventListener('submit', () => {
    formInputs.forEach(input => {
        localStorage.removeItem(`contactForm_${input.id}`);
    });
});

// ========================================
// CARRUSEL AUTOMÁTICO
// ========================================

const carouselTrack = document.querySelector('.carousel-track');
const carouselSlides = document.querySelectorAll('.carousel-slide');
let currentSlide = 0;
const slideInterval = 5000;

function showSlide(index) {
    if (!carouselTrack) return;
    const totalSlides = carouselSlides.length;
    currentSlide = (index + totalSlides) % totalSlides;
    const offset = currentSlide * -100;
    carouselTrack.style.transform = `translateX(${offset}%)`;
}

function startCarousel() {
    if (!carouselTrack || carouselSlides.length <= 1) return;
    setInterval(() => {
        showSlide(currentSlide + 1);
    }, slideInterval);
}

startCarousel();

function scrollToSection(sectionId) {
    const target = document.getElementById(sectionId);
    if (target) {
        target.scrollIntoView({ behavior: 'smooth' });
    }
}

// ========================================
// DETECCIÓN DE NAVEGADOR E IDIOMA
// ========================================

// Detectar idioma del navegador (para futuras características multilingües)
function getNavigatorLanguage() {
    return navigator.language || navigator.userLanguage;
}

console.log('Idioma del navegador:', getNavigatorLanguage());

// ========================================
// INICIALIZACIÓN
// ========================================

document.addEventListener('DOMContentLoaded', () => {
    console.log('Página cargada correctamente');
    // Aquí puedes agregar más funcionalidades de inicialización
});
