# TODO - Bufete Justicia (Equipo: jueces y abogados)

- [x] Actualizar `app.py`: usar las 10 imágenes desde `imge/` y devolver campos `bio` y `experiencia` para cada miembro.
- [x] Crear/ajustar rutas para servir imágenes desde `imge/` sin tocar otras partes.

- [x] Crear una nueva plantilla `templates/equipo_abogados_jueces.html` con: carrusel, buscador, secciones (Abogados y Jueces/Juezas), logo y fondo.
- [x] Actualizar `templates/equipo.html` para que muestre los nuevos campos o redirija/integre la nueva plantilla sin romper lo existente.


- [x] Actualizar el número de WhatsApp en el código para que sea +54 9 364 436-9163.
- [x] Probar que `/equipo` renderiza correctamente y que el buscador filtra por nombre/rol/especialidad.


