from flask import Flask, jsonify, render_template, request, redirect, url_for, session, flash, send_from_directory

from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os
import qrcode
import time
import random
import uuid

try:
    from twilio.rest import Client
except Exception:
    Client = None

app = Flask(__name__)
app.secret_key = os.environ.get('FLASK_SECRET', 'mi_clave_secreta_super_segura_123')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///legal_firm.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

TWILIO_ACCOUNT_SID = os.environ.get('TWILIO_ACCOUNT_SID', 'AC...')
TWILIO_AUTH_TOKEN = os.environ.get('TWILIO_AUTH_TOKEN', 'tu_auth_token_aqui')
TWILIO_WHATSAPP_NUMBER = os.environ.get('TWILIO_WHATSAPP_NUMBER', 'whatsapp:+1234567890')

if Client:
    try:
        twilio_client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
    except Exception as e:
        twilio_client = None
        print(f'⚠️ Advertencia: Twilio no inicializado. {e}')
else:
    twilio_client = None
    print('⚠️ Advertencia: la librería Twilio no está instalada. Las notificaciones WhatsApp no funcionarán.')


class Usuario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)

    def __repr__(self):
        return f'<Usuario {self.username}>'


class Documento(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(150), nullable=False)
    precio = db.Column(db.Float, nullable=False)
    categoria = db.Column(db.String(80), nullable=True)
    descripcion = db.Column(db.String(250), nullable=True)

    def __repr__(self):
        return f'<Documento {self.nombre}>'

    def to_dict(self):
        return {
            'id': self.id,
            'nombre': self.nombre,
            'precio': self.precio,
            'categoria': self.categoria,
            'descripcion': self.descripcion,
        }


class Reserva(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ticket = db.Column(db.String(30), unique=True, nullable=False)
    nombre = db.Column(db.String(120), nullable=False)
    telefono = db.Column(db.String(30), nullable=False)
    servicio = db.Column(db.String(120), nullable=False)
    estado = db.Column(db.String(40), nullable=False, default='Pendiente')
    creado_en = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, nullable=True)
    qr_path = db.Column(db.String(255), nullable=True)
    whatsapp_entregado = db.Column(db.Boolean, default=False)

    def __repr__(self):
        return f'<Reserva {self.ticket}>'

    def to_dict(self):
        return {
            'id': self.ticket,
            'nombre': self.nombre,
            'telefono': self.telefono,
            'servicio': self.servicio,
            'estado': self.estado,
            'creado_en': self.creado_en.isoformat(),
            'whatsapp_entregado': self.whatsapp_entregado,
        }


def obtener_servicios_juridicos():
    return [
        {'nombre': 'Consulta Penal Integral', 'precio': 120.0, 'disponible': True, 'categoria': 'Penal'},
        {'nombre': 'Defensa Civil y Laboral', 'precio': 95.0, 'disponible': True, 'categoria': 'Laboral'},
        {'nombre': 'Redacción de Contratos', 'precio': 150.0, 'disponible': True, 'categoria': 'Corporativo'},
        {'nombre': 'Asesoría Empresarial', 'precio': 180.0, 'disponible': True, 'categoria': 'Corporativo'},
        {'nombre': 'Análisis de Sentencias', 'precio': 110.0, 'disponible': True, 'categoria': 'Judicial'},
        {'nombre': 'Gestión de Casos Judiciales', 'precio': 135.0, 'disponible': False, 'categoria': 'Judicial'},
    ]


def obtener_equipo_legal():
    # Miembros (abogados/jueces) usando las imágenes provistas en /imge
    return [
        {
            'id': 1,
            'tipo': 'abogado',
            'nombre': 'Abogada Mariela Alejandra Pérez',
            'rol': 'Abogada',
            'imagen': '/imge/abogada Mariela Alejandra Pérez.jpg',
            'especialidad': 'Defensa penal y estrategias procesales',
            'bio': 'Asistencia jurídica integral con enfoque práctico y seguimiento de cada etapa del caso.',
            'experiencia': 'Estrategias de litigio, preparación de escritos y acompañamiento a audiencias.',
        },
        {
            'id': 2,
            'tipo': 'abogado',
            'nombre': 'Abogada Elena Gabriela Valeria',
            'rol': 'Abogada',
            'imagen': '/imge/abogadaElena Gabriela Valeria.jpg',
            'especialidad': 'Derecho civil y asesoramiento contractual',
            'bio': 'Contratos, reclamos y asesoría personalizada con claridad y precisión.',
            'experiencia': 'Redacción y revisión de acuerdos, negociación y gestión de conflictos.',
        },
        {
            'id': 3,
            'tipo': 'abogado',
            'nombre': 'Abogado Daniel Oscar Buryaile',
            'rol': 'Abogado',
            'imagen': '/imge/abogado Daniel Oscar Buryaile.jpg',
            'especialidad': 'Laboral y defensa en conflictos de trabajo',
            'bio': 'Defensa con foco en la prueba, el derecho aplicable y la estrategia de negociación.',
            'experiencia': 'Presentación de demandas, contestaciones y representación en audiencias.',
        },
        {
            'id': 4,
            'tipo': 'abogado',
            'nombre': 'Abogado Facundo Gastón Cabañas',
            'rol': 'Abogado',
            'imagen': '/imge/abogado Facundo Gastón Cabañas.jpg',
            'especialidad': 'Empresarial y corporativo',
            'bio': 'Asesoramiento para empresas: contratos, cumplimiento y decisiones informadas.',
            'experiencia': 'Análisis jurídico, documentación corporativa y acompañamiento en operaciones.',
        },
        {
            'id': 5,
            'tipo': 'abogado',
            'nombre': 'Abogado Sergio Gustavo Sánchez',
            'rol': 'Abogado',
            'imagen': '/imge/abogado Sergio Gustavo Sánchez.jpg',
            'especialidad': 'Judicial y recursos',
            'bio': 'Trabajo de estrategia orientado a resultados con lectura integral del expediente.',
            'experiencia': 'Redacción de escritos, seguimiento de causas y preparación de recursos.',
        },
        {
            'id': 6,
            'tipo': 'juez',
            'nombre': 'Juez Mariano Borinsky',
            'rol': 'Juez',
            'imagen': '/imge/juez Mariano Borinsky.jpg',
            'especialidad': 'Criterio judicial y dirección de proceso',
            'bio': 'Experiencia en criterios jurisdiccionales, garantizando el debido proceso.',
            'experiencia': 'Resolución de conflictos, análisis de prueba y fundamentos jurídicos.',
        },
        {
            'id': 7,
            'tipo': 'juez',
            'nombre': 'Juez Víctor Emilio del Río',
            'rol': 'Juez',
            'imagen': '/imge/juez Víctor Emilio del Río.jpg',
            'especialidad': 'Asesoría judicial y enfoque procesal',
            'bio': 'Orientación con mirada técnica del procedimiento y la interpretación normativa.',
            'experiencia': 'Gestión de casos y revisión de fundamentos para decisiones.',
        },
        {
            'id': 8,
            'tipo': 'juez',
            'nombre': 'Jueza Emilia María Valle',
            'rol': 'Jueza',
            'imagen': '/imge/jueza Emilia María Valle.jpg',
            'especialidad': 'Tratamiento de casos y criterios de sentencia',
            'bio': 'Análisis integral del caso para definir la mejor ruta jurídica.',
            'experiencia': 'Dirección y evaluación de pruebas, con rigor argumental.',
        },
        {
            'id': 9,
            'tipo': 'juez',
            'nombre': 'Jueza Zunilda Niremperger',
            'rol': 'Jueza',
            'imagen': '/imge/jueza Zunilda Niremperger.jpg',
            'especialidad': 'Derecho aplicable y evaluación de antecedentes',
            'bio': 'Capacidad para ordenar la información del expediente y proponer estrategias consistentes.',
            'experiencia': 'Fundamentación jurídica y valoración de documentación del caso.',
        },
        {
            'id': 10,
            'tipo': 'juez',
            'nombre': 'Juez Ricardo Alcides Mianovich',
            'rol': 'Juez',
            'imagen': '/imge/Ricardo Alcides Mianovich juez.jpg',
            'especialidad': 'Criterio judicial y revisión de casos',
            'bio': 'Experiencia en procesos judiciales con enfoque en la coherencia argumental.',
            'experiencia': 'Análisis de expedientes, criterios y resolución fundada.',
        },
    ]



def seed_documentos():
    if Documento.query.count() == 0:
        muestras = [
            {'nombre': 'Contrato de Arrendamiento', 'precio': 75.0, 'categoria': 'Civil', 'descripcion': 'Modelo de contrato para alquiler residencial o comercial.'},
            {'nombre': 'Documento de Power of Attorney', 'precio': 95.0, 'categoria': 'Corporativo', 'descripcion': 'Poder para representación legal en gestiones empresariales.'},
            {'nombre': 'Acuerdo de Confidencialidad', 'precio': 65.0, 'categoria': 'Compliance', 'descripcion': 'NDA estándar para socios y colaboradores.'},
            {'nombre': 'Demanda Laboral', 'precio': 120.0, 'categoria': 'Laboral', 'descripcion': 'Plantilla profesional para reclamos de indemnización.'},
            {'nombre': 'Escrito de Apelación', 'precio': 140.0, 'categoria': 'Judicial', 'descripcion': 'Formato listo para presentar recursos de apelación.'},
        ]
        for doc in muestras:
            db.session.add(Documento(**doc))
        db.session.commit()


with app.app_context():
    db.create_all()
    seed_documentos()


@app.route('/')
def home():
    servicios = obtener_servicios_juridicos()[:4]
    equipo_preview = obtener_equipo_legal()[:4]
    return render_template('index.html', titulo='Bufete Justicia', servicios=servicios, equipo=equipo_preview, whatsapp='+54 9 364 436-9163', usuario=session.get('username'))


@app.route('/registro', methods=['GET', 'POST'])
def registro():
    if request.method == 'POST':
        usuario = request.form.get('username')
        clave = request.form.get('password')
        if not usuario or not clave:
            flash('⚠️ Usuario y contraseña son obligatorios.', 'error')
            return render_template('registro.html')

        hash_seguro = generate_password_hash(clave, method='scrypt')
        nuevo_usuario = Usuario(username=usuario, password_hash=hash_seguro)
        try:
            db.session.add(nuevo_usuario)
            db.session.commit()
            flash('✅ Registro exitoso. Ahora puedes iniciar sesión.', 'success')
            return redirect(url_for('login'))
        except Exception:
            db.session.rollback()
            flash('❌ Ese nombre de usuario ya existe.', 'error')
    return render_template('registro.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = Usuario.query.filter_by(username=username).first()
        if user and check_password_hash(user.password_hash, password):
            session['user_id'] = user.id
            session['username'] = user.username
            flash(f'✅ ¡Bienvenido {username}! Acceso autorizado al panel jurídico.', 'success')
            return redirect(url_for('dashboard'))
        flash('❌ Credenciales inválidas. Inténtalo de nuevo.', 'error')
    return render_template('login.html')


@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        flash('⚠️ Debes iniciar sesión para acceder al panel.', 'warning')
        return redirect(url_for('login'))

    total_reservas = Reserva.query.filter_by(user_id=session['user_id']).count()
    proximas_reservas = Reserva.query.filter_by(user_id=session['user_id']).order_by(Reserva.creado_en.desc()).limit(5).all()
    return render_template('dashboard.html', nombre=session['username'], total_reservas=total_reservas, proximas_reservas=proximas_reservas, titulo='Panel de Usuario')


@app.route('/logout')
def logout():
    session.clear()
    flash('👋 Has cerrado sesión correctamente.', 'info')
    return redirect(url_for('login'))


@app.route('/reservas')
def reservas():
    servicios = obtener_servicios_juridicos()
    return render_template('reserva.html', titulo='Agendar Consulta Jurídica', servicios=servicios, usuario=session.get('username'))


@app.route('/reservar', methods=['POST'])
def reservar():
    nombre = request.form.get('nombre')
    telefono = request.form.get('telefono')
    servicio = request.form.get('servicio')

    if not nombre or not telefono or not servicio:
        flash('❌ Todos los campos son obligatorios.', 'error')
        return redirect(url_for('reservas'))

    if not telefono.startswith('+'):
        flash('⚠️ El teléfono debe incluir el + y código de país (ej: +5493644369163).', 'error')
        return redirect(url_for('reservas'))

    ticket_id = f'LEX-{uuid.uuid4().hex[:8].upper()}'
    qr_data = f'Ticket: {ticket_id} | Cliente: {nombre} | Servicio: {servicio}'
    qr_folder = 'static/qrs'
    os.makedirs(qr_folder, exist_ok=True)
    qr_path = os.path.join(qr_folder, f'{ticket_id}.png')

    try:
        qr = qrcode.QRCode(version=1, box_size=10, border=4)
        qr.add_data(qr_data)
        qr.make(fit=True)
        img = qr.make_image(fill_color='black', back_color='white')
        img.save(qr_path)
    except Exception as e:
        print('❌ Error generando QR:', e)
        flash('Error interno al procesar el código QR.', 'error')
        return redirect(url_for('reservas'))

    reserva = Reserva(ticket=ticket_id, nombre=nombre, telefono=telefono, servicio=servicio, estado='Confirmado', user_id=session.get('user_id'), qr_path=qr_path)

    try:
        db.session.add(reserva)
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        print('❌ Error guardando reserva:', e)
        flash('Error interno al guardar la reserva.', 'error')
        return redirect(url_for('reservas'))

    mensaje_texto = f'''¡Hola {nombre}!\n\nTu consulta de '{servicio}' ha sido agendada.\n\nCódigo de reserva: {ticket_id}\n\nNos comunicaremos contigo al número {telefono}.\n\nBufete Justicia - WhatsApp: +54 9 364 436-9163'''

    if twilio_client:
        try:
            mensaje = twilio_client.messages.create(body=mensaje_texto, from_=TWILIO_WHATSAPP_NUMBER, to=f'whatsapp:{telefono}')
            reserva.whatsapp_entregado = True
            db.session.commit()
            flash(f'✅ Reserva confirmada. Mensaje enviado a WhatsApp {telefono}.', 'success')
        except Exception as e:
            db.session.rollback()
            print('⚠️ Error de WhatsApp:', e)
            flash(f'⚠️ Reserva creada ({ticket_id}), pero no se pudo enviar WhatsApp.', 'warning')
    else:
        flash(f'✅ Reserva confirmada. Código: {ticket_id}. Envío de WhatsApp no disponible.', 'success')

    return redirect(url_for('reservas'))


@app.route('/reservas_lista')
def reservas_lista():
    if 'user_id' not in session:
        flash('⚠️ Debes iniciar sesión para ver tus consultas.', 'warning')
        return redirect(url_for('login'))
    reservas = Reserva.query.filter_by(user_id=session['user_id']).order_by(Reserva.creado_en.desc()).all()
    return render_template('reservas_lista.html', titulo='Mis Consultas', nombre=session['username'], reservas=reservas)


@app.route('/api/reservas', methods=['GET'])
def api_obtener_reservas():
    if 'user_id' not in session:
        return jsonify({'error': 'No autorizado'}), 403
    time.sleep(1.5)
    reservas = Reserva.query.filter_by(user_id=session['user_id']).order_by(Reserva.creado_en.desc()).all()
    return jsonify([r.to_dict() for r in reservas])


@app.route('/api/reservas/crear', methods=['POST'])
def api_crear_reserva_simulada():
    if 'user_id' not in session:
        return jsonify({'error': 'No autorizado'}), 403
    time.sleep(1.5)
    servicios = [s['nombre'] for s in obtener_servicios_juridicos()]
    ticket_id = f'LEX-{random.randint(1000, 9999)}'
    reserva = Reserva(ticket=ticket_id, nombre='Reserva Demo', telefono='+549000000000', servicio=random.choice(servicios), estado='Confirmado', user_id=session['user_id'])
    db.session.add(reserva)
    db.session.commit()
    return jsonify(reserva.to_dict()), 201


@app.route('/api/reservas/limpiar', methods=['POST'])
def api_limpiar_reservas_simuladas():
    if 'user_id' not in session:
        return jsonify({'error': 'No autorizado'}), 403
    time.sleep(1)
    Reserva.query.filter_by(user_id=session['user_id']).delete()
    db.session.commit()
    return jsonify({'status': 'success'}), 200


@app.route('/servicios')
def servicios():
    datos_servicios = obtener_servicios_juridicos()
    return render_template('servicios.html', titulo='Servicios Jurídicos', servicios=datos_servicios, usuario=session.get('username'))


@app.route('/equipo')
def equipo():
    equipo_legal = obtener_equipo_legal()
    return render_template('equipo_abogados_jueces.html', titulo='Equipo Jurídico', equipo=equipo_legal, usuario=session.get('username'))



@app.route('/catalogo')
def catalogo():
    documentos = Documento.query.all()
    return render_template('catalogo.html', titulo='Biblioteca Jurídica', productos=documentos, usuario=session.get('username'))


@app.route('/documentos')
def documentos():
    return redirect(url_for('catalogo'))


@app.route('/biblioteca')
def biblioteca():
    return redirect(url_for('catalogo'))


@app.route('/buscador')
def buscador():
    return render_template('buscador.html', titulo='Buscador Jurídico', usuario=session.get('username'))


@app.route('/agregar', methods=['POST'])
def agregar_producto():
    nombre = request.form.get('nombre')
    precio = request.form.get('precio')
    categoria = request.form.get('categoria')
    descripcion = request.form.get('descripcion', 'Documento legal disponible para descarga.')
    if nombre and precio:
        try:
            nuevo_documento = Documento(nombre=nombre, precio=float(precio), categoria=categoria, descripcion=descripcion)
            db.session.add(nuevo_documento)
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            print('ERROR al agregar documento:', e)
    return redirect(url_for('catalogo'))


@app.route('/borrar/<int:id>')
def eliminar_producto(id):
    documento = Documento.query.get(id)
    if documento:
        db.session.delete(documento)
        db.session.commit()
    return redirect(url_for('catalogo'))


@app.route('/editar/<int:id>', methods=['GET', 'POST'])
def editar_producto(id):
    documento = Documento.query.get(id)
    if not documento:
        return redirect(url_for('catalogo'))
    if request.method == 'POST':
        nombre = request.form.get('nombre')
        precio = request.form.get('precio')
        categoria = request.form.get('categoria')
        descripcion = request.form.get('descripcion', documento.descripcion)
        if nombre and precio:
            try:
                documento.nombre = nombre
                documento.precio = float(precio)
                documento.categoria = categoria
                documento.descripcion = descripcion
                db.session.commit()
            except Exception as e:
                db.session.rollback()
                print('ERROR al editar documento:', e)
        return redirect(url_for('catalogo'))
    return render_template('editar.html', titulo='Editar Documento Jurídico', producto=documento, usuario=session.get('username'))


@app.route('/api/hola')
def hola_json():
    return jsonify({
        'status': 'success',
        'mensaje': '¡Hola Mundo desde Bufete Justicia!'
    })


@app.route('/api/buscar')
def buscar_productos():
    query_text = request.args.get('q', '').lower()
    if not query_text:
        return jsonify([])
    resultados = Documento.query.filter(Documento.nombre.ilike(f'%{query_text}%')).all()
    return jsonify([p.to_dict() for p in resultados])


@app.route('/contacto', methods=['GET', 'POST'])
def contacto():
    mensaje_error = None
    mensaje_exito = None
    if request.method == 'POST':
        nombre = request.form.get('nombre')
        email = request.form.get('email')
        telefono = request.form.get('telefono')
        mensaje = request.form.get('mensaje')
        if not nombre or not email or not telefono:
            mensaje_error = '⚠️ Los campos Nombre, Email y Teléfono son obligatorios.'
        elif '@' not in email or '.' not in email:
            mensaje_error = '📧 El formato del correo electrónico no es válido.'
        elif not telefono.replace('+', '').isdigit() or len(telefono) < 7:
            mensaje_error = '📞 Por favor, ingresa un número de teléfono válido.'
        else:
            mensaje_exito = f'✅ ¡Perfecto {nombre}! Hemos recibido tu solicitud y en breve te contactaremos.'
            print(f'DEBUG: Contacto -> {nombre}, {email}, {telefono}, mensaje={mensaje}')
    return render_template('contacto.html', titulo='Contacto Jurídico', error=mensaje_error, exito=mensaje_exito, whatsapp='+54 9 364 436-9163', usuario=session.get('username'))


@app.route('/imge/<path:filename>')
def servir_imge(filename):
    # Sirve tus imágenes desde la carpeta /imge
    return send_from_directory('imge', filename)


if __name__ == '__main__':
    app.run(debug=True)

